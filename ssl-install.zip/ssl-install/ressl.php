<?php
// Copy this file to the public_html directory and point it to the script folder
// It's safer than putting the all the script in a public accessible folder
$scriptDir = dirname(__FILE__);
chdir($scriptDir);
require("index.php");