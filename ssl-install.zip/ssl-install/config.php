<?php

// Get current script path and domain
$scriptPath = __FILE__;
$hostDomain = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';

// Extract username from the path: e.g., /home/govregistrar/...
preg_match('#^/home/([^/]+)/#', $scriptPath, $matches);
$username = isset($matches[1]) ? $matches[1] : 'defaultuser';

// Construct dynamic values
$publicPath = "/home/" . $username . "/public_html";
$cpanelHost = "https://" . $hostDomain . ":2083";
$domains = array($hostDomain, "www." . $hostDomain);

return array(
    'testing' => false,
    'minDays' => 15, // Minimum days to wait before requesting new certificates
    'cpanel' => array(
        'host' => $cpanelHost,
        'username' => $username,
        'password' => '!!Down12manyNinjaMain',
        // 'token' => 'YOUR_TOKEN_IF_USED'
    ),
    'accounts' => array(
        array(
            'email' => 'mosesmn@gmail.com',
            'publicPath' => $publicPath,
            'domains' => $domains,
            'disabled' => false,
        ),
    )
);
