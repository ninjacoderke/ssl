<?php

return [
    'testing' => false,
    'minDays' => 15, // Minimum days to wait before requesting new certificates
    'cpanel' => [
        'host' => 'https://govregistrar.com:2083', 
        'username' => 'lexxil',
        'password' => '!!Down12manyNinjaMain',
//'token' => 'JN9XXKM1KC4OQ4G3GW24ZTW02QI87VMH'
//'token' => 'GAF0GYR55AEQ7OVV7E77W21Q774QR5PF'


    ],
    'accounts' => [
        [
            'email' => 'mosesmn@gmail.com',
            'publicPath' => '../public_html', // related to the script location, no trailing /
            'domains' => ['lexxil.com', 'www.lexxil.com'],
            'disabled' => false,
        ],
    ]
];

